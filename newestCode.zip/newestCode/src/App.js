import React from "react";
import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom";
import Header from "./components/Header";
import MonitorInstructions from "./pages/MonitorInstructions";
import Dashboard from "./pages/Dashboard";
import ClientPayments from "./pages/ClientPaymentList";
import UploadProof from "./pages/UploadProof";
import LogoutButton from "./components/LogoutButton";
import ClientDocuments from "./pages/ClientDocuments";
import DriverWage from "./pages/DriverWage";
import Expenses from "./pages/Expenses";
import Analytics from "./pages/Analytics";
import Debtors from "./pages/Debtors"; 
import Manage from "./pages/Manage";
import "./css/card.css";
import "./css/components.css";
import "./css/dashboard.css";
import "./css/layout.css";
import "./css/MonitorInstructions.css"


function DynamicHeader() {
  const location = useLocation();

  const titleMap = {
    "/": "Dashboard",
    "/monitor-instructions": "Instructions",
    "/client-payments": "Client Payments",
    "/client-documents": "Client Documents",
    "/driver-wage": "Wages",
    "/expenses": "Truck Expenses",
    "/analytics":"Analytics",
    "/debtors":"Debtors",
    "/manage":"Manage"
  };

  const getTitle = () => {
    if (location.pathname.startsWith("/upload")) return "Upload Payment Proof";
    return titleMap[location.pathname] || "Unknown Page";
  };
  

  return <Header title={getTitle()} />;
}


function App() {
  return (
    <Router>
      <div className="container">
        <DynamicHeader />
        <div className="content-area">
          <div className="logout-container">
            <LogoutButton />
          </div>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/monitor-instructions" element={<MonitorInstructions />} /> 
            <Route path="/client-payments" element={<ClientPayments />} />
            <Route path="/driver-wage" element={<DriverWage />} />
            <Route path="/client-documents" element={<ClientDocuments />} /> 
            <Route path="/expenses" element={<Expenses />} />
            <Route path="/upload/:companyName/:balance" element={<UploadProof />} />
            <Route path="/debtors" element={<Debtors />} />
            <Route path="/analytics" element={<Analytics />} />
            <Route path="/manage" element={<Manage />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;
